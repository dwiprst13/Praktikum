function say() {
    alert("Ayo Semangat Praktikum");
}
